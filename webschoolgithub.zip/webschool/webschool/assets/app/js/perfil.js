const oi = document.querySelector('.user-profile main .head > div .info-profile .profile-photo .icon-altern-photo')

oi.addEventListener('click', ()=> {
    alert('oi')
})

const coverEdit = document.querySelector('.btn-altern-cover')

coverEdit.addEventListener('click', ()=> {
    alert('Editar capa e perfil')
})
