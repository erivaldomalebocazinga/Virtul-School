"use strict";
/* MAIN */

/* ---------------- Modal Feed ---------------- */
const SettingsFeed = document.querySelectorAll('.edit i.fa-ellipsis'),
    li = document.querySelectorAll('.edit .modal-settings-feed')

SettingsFeed.forEach((elemento) => {
  elemento.addEventListener('click', (event) => {
    // Oculta todos os elementos
    li.forEach((e) => {
      e.style.display = 'none';
    });

    // Exibe somente o elemento clicado
    const elementoClicado = event.currentTarget;
    elementoClicado.classList.add('active'); // ou 'flex', dependendo do elemento

    if(elementoClicado.classList.contains('active')) {
        li.forEach((el) => {
            el.style.display = 'block'
        });
    }else {

    }
  });
});





/* ==========  SEARCH MESSAGE ============= */
function searchMessages() {
    document.querySelector('.search-messages input[type="search"]').addEventListener('keyup', (e) => {
        let textImput = e.target.value
    console.log(
        textImput =  textImput.toLowerCase())
    
        let messageItem = document.querySelectorAll('.message .message-body h4'),
        messageBox = document.querySelectorAll('.message')
    
        for (let i = 0; i < messageItem.length; i++) {
            if(!messageItem[i].innerHTML.toLowerCase().includes(textImput)) {
                messageBox[i].style.display="none"
            }else {
                messageBox[i].style.display="flex"
            }              
        }
    
    })
}

searchMessages()


/* ======== FAST MESSAGE ========= */
const FastMessage = document.querySelector('.fastMessage input[type="text"]')
const message = document.querySelectorAll('.message')
const spaceVaco = document.querySelector('.selectFastMassage')

message.forEach(msg => {
    msg.addEventListener('click', ()=> {


    spaceVaco.insertAdjacentHTML('beforeend', elementMesssage)//incabado!!

    })
})
    


//POST - (Numero de post)

const contPhoto = document.querySelectorAll('.photo')

contPhoto.forEach(f => {
    console.log(f)
    let count = f.querySelectorAll('img')
    count = count.length 
    console.log(count)

    if (count == 2) {
        if(!f.classList.contains('TwoPhoto')) {
            f.classList.add('TwoPhoto')
        }else {
            //já tem a classe 2
        }
    } else if (count == 3) {
        if(!f.classList.contains('threePhoto')) {
            f.classList.add('threePhoto')
        }else {
            //já tem a classe 3
        }
    } else if (count == 4) {
        if(!f.classList.contains('ForPhoto')) {
            f.classList.add('ForPhoto')
        }else {
            //já tem a classe 4
        }
    } else if (count == 5 || count == 6 || count == 7) {
        if(!f.classList.contains('plusPhoto')) {
            f.classList.add('plusPhoto')
        }else {
            //já tem a classe plusPhoto
        }
    }

})

const photoItem = document.querySelectorAll('.photo.threePhoto img')

photoItem.forEach(imgThree => {
    let img1 = imgThree.classList.contains('img1'),
        img2 = imgThree.classList.contains('img2'),
        img3 = imgThree.classList.contains('img3');

        let i = 1
        imgThree.classList.add(`img${i}`)//inacabado!!
        
})
