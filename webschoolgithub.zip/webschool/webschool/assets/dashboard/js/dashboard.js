"use strict";

/* ==================== sidebar code ======================== */
const SidebarItems = document.querySelectorAll('.sidebar-items')

/* remover a class active  */
const changeActiveItem = ()=> {
    SidebarItems.forEach(item => {
         item.classList.remove('active')
    })
}
SidebarItems.forEach(item => {
    item.addEventListener('click', ()=> {
        changeActiveItem() //chamada da função que irá remover a class 'active' da sidebar  
        item.classList.add('active')
        if(item.id != 'messages') {
            /* document.querySelector('.notifications-popup').style.display = 'none'; */
        } else{
           /*  document.querySelector('.notifications-popup').style.display = 'block'; */
            document.querySelector('.notification-count').style.display = 'none'; //irá remover o contador de notificações
        }
    })
})

/* ======== Link da photo de perfil com o perfil ======= */
const urlProfile = document.querySelector('.profile-photo.urlProfile').addEventListener('click', ()=> {
    location.replace('../perfil.html')
})


//Filtro da lista de alunos do dashboard
//Variaveis do filtro:
const selectorFiltro = document.querySelectorAll('.typefiltro .select-filtro')
const x = document.querySelectorAll('.typefiltro .modal-filtro')

const modalFiltroCursoItems = document.querySelectorAll('#modal-filtro-curso label')
//Filtro de filtro

addEventListener('click', function (event) {

    if(selectorFiltro[1].contains(event.target)) {
        x[0].classList.toggle('active')
    } else if(!selectorFiltro[1].contains(event.target))  {
        x[0].classList.remove('active')
    }

    if(selectorFiltro[2].contains(event.target)) {
        x[1].classList.toggle('active')
    } else if(!selectorFiltro[2].contains(event.target))  {
        x[1].classList.remove('active')
    }

    if(selectorFiltro[3].contains(event.target)) {
        x[2].classList.toggle('active')
    } else if(!selectorFiltro[3].contains(event.target))  {
        x[2].classList.remove('active')
    }
})
 

modalFiltroCursoItems.forEach(filt => {
    let ensinoGeral = document.querySelector('.ensino-geral '),
        cursoTecnico = document.querySelector('.curso-tecnico');

    filt.addEventListener('click', ()=> { 
        const labelEnsGeral = document.querySelector('#modal-filtro-curso label.ensGeral')
        const labelTodosCursos = document.querySelector('#modal-filtro-curso label.todoscursos')
        if(labelEnsGeral == filt) {
            ensinoGeral.style.display = 'flex'
            cursoTecnico.style.display = 'none'
        } else if(labelTodosCursos == filt){
            ensinoGeral.style.display = 'flex'
            cursoTecnico.style.display = 'flex'
        } else{
            ensinoGeral.style.display = 'none'
            cursoTecnico.style.display = 'flex'
        }
    })
})
